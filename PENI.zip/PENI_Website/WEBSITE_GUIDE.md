# PENI Website Guide

**Brand:** PENI  
**Tagline:** Outfits worth every penny.  
**Visual style:** Editorial, bold black-and-white, responsive, no product photographs.

## Customer pages

- Home (`public/index.html`) — Editorial hero, featured pieces, brand positioning.
- Collection (`public/catalog.html`) — Twelve initial pieces, working Senator / Agbada / Traditional filtering.
- Bag (`public/cart.html`) — Quantity adjustment, delivery and Paystack hosted checkout.
- Payment confirmation (`public/payment-result.html`) — Checks the order with the secured API, never assumes payment succeeded.
- The PENI Edit (`public/services.html`) — The brand's collection and style point of view.
- About (`public/about.html`) — Story and brand identity.
- Contact (`public/contact.html`) — Live form submissions to Firestore after Firebase deployment.
- Reviews (`public/reviews.html`) — User-generated reviews after admin approval.
- Privacy/Terms (`public/privacy.html`, `public/terms.html`) — Draft operational policies to finalize before launch.

## Admin pages

- Admin Login (`public/admin-login.html`) — Email/password via Firebase Authentication, no demo credentials.
- Dashboard (`public/admin-dashboard.html`) — Live metrics and orders, product editor, customers, enquiry tracking and review moderation. Access controlled by Firebase custom `admin` claim checked server-side.

**To activate real payments and admin accounts:** Follow the exact deployment sequence in `README.md`. The public merchant information and Firebase Web App config are intentionally blank until the owner provides them in the designated secure settings.
