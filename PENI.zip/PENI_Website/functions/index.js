'use strict';
const express = require('express');
const crypto = require('node:crypto');
const {onRequest} = require('firebase-functions/v2/https');
const {defineSecret} = require('firebase-functions/params');
const {initializeApp} = require('firebase-admin/app');
const {getAuth} = require('firebase-admin/auth');
const {getFirestore,FieldValue} = require('firebase-admin/firestore');
const defaults = require('./seed-products.json');
initializeApp();
const db = getFirestore();
const paystackSecret = defineSecret('PAYSTACK_SECRET_KEY');
const app = express();
app.disable('x-powered-by');
app.use(express.json({limit:'20kb'}));
const router = express.Router();
const deliveryPrices={standard:0,express:15000};
const categories=new Set(['senator','agbada','traditional']);
const fail=(res,status,message)=>res.status(status).json({error:message});
const clean=(val,max=150)=>typeof val==='string'?val.trim().slice(0,max):'';
const validEmail=e=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length<=160;
const sameOriginOnly=(req,res,next)=>{
  // Browser writes are expected from our Hosting origin. Cross-site form submits are
  // blocked by JSON parsing + CORS defaults; authenticated endpoints also verify JWT.
  const origin=req.get('origin');const site=process.env.SITE_URL;
  if(origin && site && new URL(origin).origin!==new URL(site).origin) return fail(res,403,'Invalid request origin.');
  next();
};

async function catalogAll(){
  const docs=await db.collection('products').get();
  const entries=new Map(defaults.map(p=>[p.id,{...p}]));
  for(const doc of docs.docs){entries.set(doc.id,{...entries.get(doc.id),...doc.data(),id:doc.id});}
  return [...entries.values()];
}
async function paystack(path,options={}){
  const secret=paystackSecret.value();
  if(!secret || !secret.startsWith('sk_')) throw Object.assign(new Error('Payment gateway is not configured.'),{statusCode:503});
  const abort=new AbortController();const timeout=setTimeout(()=>abort.abort(),15000);
  try{
    const resp=await fetch(`https://api.paystack.co/${path}`,{...options,signal:abort.signal,headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/json',...(options.headers||{})}});
    const data=await resp.json();
    if(!resp.ok||data.status!==true)throw new Error('Payment provider could not process this request.');
    return data.data;
  }finally{clearTimeout(timeout)}
}
async function verifyReference(reference){
  const orderRef=db.collection('orders').doc(reference);const doc=await orderRef.get();if(!doc.exists)return {status:'unknown'};
  const order=doc.data();if(order.paymentStatus==='paid')return {status:'paid'};
  const data=await paystack(`transaction/verify/${encodeURIComponent(reference)}`);
  const email=String(data.customer?.email||'').toLowerCase();
  const approved=data.status==='success' && data.reference===reference && data.currency==='NGN' && Number(data.amount)===Number(order.total)*100 && email===String(order.customer.email).toLowerCase();
  if(approved){await db.runTransaction(async tx=>{const latest=await tx.get(orderRef);if(latest.exists&&latest.data().paymentStatus!=='paid')tx.update(orderRef,{paymentStatus:'paid',paidAt:new Date().toISOString(),paystackId:String(data.id||''),paymentChannel:String(data.channel||'')})});return {status:'paid'}}
  // A successful gateway status without a matching reference, amount, currency,
  // or payer is NEVER accepted as a successful order. Flag it for investigation.
  if(data.status==='success'){
    console.error('PENI payment data mismatch',reference);
    return {status:'pending'};
  }
  // A failed checkout should be clearly identified. The cart is retained so
  // the customer can choose whether to start a NEW checkout attempt.
  if(data.reference===reference && ['failed','abandoned','reversed'].includes(data.status)){
    await db.runTransaction(async tx=>{const latest=await tx.get(orderRef);if(latest.exists&&latest.data().paymentStatus!=='paid')tx.update(orderRef,{paymentStatus:'failed',paymentFailedAt:new Date().toISOString()})});
    return {status:'failed'};
  }
  return {status:'pending'};
}
async function requireAdmin(req,res,next){
  try{const match=/^Bearer (.+)$/.exec(req.get('authorization')||'');if(!match)return fail(res,401,'Please sign in.');const token=await getAuth().verifyIdToken(match[1],true);if(token.admin!==true)return fail(res,403,'You do not have administrator permission.');req.admin=token;next()}catch{return fail(res,401,'Session expired or invalid. Please sign in again.')}
}
router.get('/products',async(req,res)=>{
  try{const products=(await catalogAll()).filter(p=>p.active!==false&&!p.deleted);res.set('Cache-Control','public, max-age=60');res.json({products})}catch(err){console.error('catalog read',err);fail(res,503,'Catalog temporarily unavailable.')}
});
router.post('/checkout',sameOriginOnly,async(req,res)=>{
  try{
    const c=req.body?.customer||{};
    const customer={name:clean(c.name,100),email:clean(c.email,160).toLowerCase(),phone:clean(c.phone,30),address:clean(c.address,220),city:clean(c.city,80),state:clean(c.state,80)};
    if(!customer.name || customer.name.length<2 || !validEmail(customer.email) || !customer.phone || !customer.address || !customer.city || !customer.state)return fail(res,400,'Complete your name, email, phone and delivery address.');
    const raw=req.body?.items;
    if(!Array.isArray(raw)||!raw.length||raw.length>30)return fail(res,400,'Your bag is empty or contains too many items.');
    if(!Object.hasOwn(deliveryPrices,req.body.delivery))return fail(res,400,'Choose a valid delivery method.');
    const catalog=new Map((await catalogAll()).filter(p=>p.active!==false&&!p.deleted).map(p=>[p.id,p]));
    const seen=new Set(),items=[];
    for(const entry of raw){const id=String(entry?.id||''),qty=entry?.quantity;if(seen.has(id)||!Number.isInteger(qty)||qty<1||qty>10)return fail(res,400,'Invalid bag quantity or duplicate item.');const product=catalog.get(id);if(!product)return fail(res,400,'One of your items is no longer available. Please refresh your bag.');seen.add(id);items.push({id,quantity:qty,name:product.name,unitPrice:product.price,total:product.price*qty})}
    const subtotal=items.reduce((s,p)=>s+p.total,0),deliveryFee=deliveryPrices[req.body.delivery],total=subtotal+deliveryFee;
    if(!Number.isSafeInteger(total)||total<100||total>100000000)return fail(res,400,'Invalid order amount.');
    const site=process.env.SITE_URL;
    if(!site || !/^https:\/\//.test(site))return fail(res,503,'Live checkout requires SITE_URL configuration.');
    const reference=`PENI-${crypto.randomUUID()}`;
    const doc=db.collection('orders').doc(reference);
    const order={reference,customer,items,subtotal,deliveryFee,delivery:req.body.delivery,total,currency:'NGN',paymentStatus:'pending',fulfillmentStatus:'new',createdAt:new Date().toISOString()};
    await doc.create(order);
    try{
      const result=await paystack('transaction/initialize',{method:'POST',body:JSON.stringify({email:customer.email,amount:total*100,currency:'NGN',reference,callback_url:new URL('/payment-result.html',site).href,metadata:{order_reference:reference,brand:'PENI'}})});
      if(typeof result.authorization_url!=='string'||!result.authorization_url.startsWith('https://checkout.paystack.com/'))throw Error('Invalid Paystack checkout URL.');
      await doc.update({paymentInitializedAt:new Date().toISOString()});
      res.status(201).json({authorizationUrl:result.authorization_url,reference});
    }catch(err){await doc.update({paymentStatus:'initialization_failed'});throw err}
  }catch(err){console.error('checkout error',err.message);fail(res,err.statusCode||503,err.statusCode===503?err.message:'Payment could not be started. Please try again later.')}
});
router.get('/order-status',async(req,res)=>{
  const reference=String(req.query.reference||'');if(!/^PENI-[0-9a-f-]{36}$/.test(reference))return fail(res,400,'Invalid payment reference.');
  try{const result=await verifyReference(reference);res.set('Cache-Control','no-store');res.json(result)}catch(err){console.error('verify error',err);fail(res,503,'Payment verification temporarily unavailable.')}
});
router.post('/paystack/webhook',async(req,res)=>{
  const signature=req.get('x-paystack-signature')||'';
  const raw=req.rawBody;
  if(!Buffer.isBuffer(raw))return fail(res,400,'Missing original request body.');
  const digest=crypto.createHmac('sha512',paystackSecret.value()||'').update(raw).digest('hex');
  const valid=signature.length===digest.length && crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(digest));
  if(!valid)return fail(res,401,'Invalid webhook signature.');
  try{if(req.body?.event==='charge.success' && /^PENI-[0-9a-f-]{36}$/.test(req.body?.data?.reference||''))await verifyReference(req.body.data.reference);res.status(200).json({ok:true})}catch(err){console.error('webhook error',err);fail(res,503,'Webhook verification failed.')}
});
router.post('/contact',sameOriginOnly,async(req,res)=>{
  const payload={name:clean(req.body?.name,100),email:clean(req.body?.email,160).toLowerCase(),subject:clean(req.body?.subject,160),message:clean(req.body?.message,4000)};
  if(payload.name.length<2||!validEmail(payload.email)||payload.subject.length<3||payload.message.length<10)return fail(res,400,'Please enter valid contact details and a message of at least 10 characters.');
  try{await db.collection('messages').add({...payload,status:'new',createdAt:new Date().toISOString()});res.status(201).json({ok:true})}catch{fail(res,503,'Messages are temporarily unavailable.')}
});
router.get('/reviews',async(req,res)=>{
  try{const docs=await db.collection('reviews').limit(200).get();const reviews=docs.docs.map(x=>({id:x.id,...x.data()})).filter(x=>x.status==='approved').sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,40).map(x=>({name:x.name,rating:x.rating,message:x.message,createdAt:x.createdAt}));res.set('Cache-Control','public, max-age=60');res.json({reviews})}catch{fail(res,503,'Reviews temporarily unavailable.')}
});
router.post('/reviews',sameOriginOnly,async(req,res)=>{
 const name=clean(req.body?.name,100),message=clean(req.body?.message,1800),rating=Number(req.body?.rating);
 if(name.length<2||message.length<15||!Number.isInteger(rating)||rating<1||rating>5)return fail(res,400,'Provide a name, 1–5 stars and at least 15 characters of feedback.');
 try{await db.collection('reviews').add({name,message,rating,status:'pending',createdAt:new Date().toISOString()});res.status(201).json({ok:true})}catch{fail(res,503,'Review submission is temporarily unavailable.')}
});
// All endpoints below this point require an authenticated Firebase user with
// an admin custom claim. Browser flags or UI visibility grant no permissions.
router.use('/admin',requireAdmin);
router.get('/admin/me',(req,res)=>res.json({ok:true,email:req.admin.email||''}));
router.get('/admin/dashboard',async(req,res)=>{
 try{
  const [orders,products,messages,reviews]=await Promise.all([db.collection('orders').orderBy('createdAt','desc').limit(200).get(),catalogAll(),db.collection('messages').orderBy('createdAt','desc').limit(100).get(),db.collection('reviews').orderBy('createdAt','desc').limit(100).get()]);
  res.set('Cache-Control','no-store');res.json({orders:orders.docs.map(x=>x.data()),products,messages:messages.docs.map(x=>({id:x.id,...x.data()})),reviews:reviews.docs.map(x=>({id:x.id,...x.data()}))});
 }catch(err){console.error('admin dashboard error',err);fail(res,503,'Admin data could not be loaded.')}
});
router.post('/admin/products',sameOriginOnly,async(req,res)=>{
 const b=req.body||{},id=b.id?clean(b.id,70):crypto.randomUUID().slice(0,12);const name=clean(b.name,100),category=clean(b.category,50),description=clean(b.description,400),price=b.price;
 if(!/^[A-Za-z0-9_-]+$/.test(id)||name.length<2||!categories.has(category)||description.length<4||!Number.isSafeInteger(price)||price<100||price>10000000||typeof b.active!=='boolean'||typeof b.featured!=='boolean')return fail(res,400,'Please enter a valid product name, category, price and description.');
 try{const p={id,name,category,description,price,active:b.active,featured:b.featured,deleted:false,updatedAt:new Date().toISOString()};await db.collection('products').doc(id).set(p,{merge:true});res.json({ok:true,product:p})}catch{fail(res,503,'Product could not be saved.')}
});
router.delete('/admin/products/:id',sameOriginOnly,async(req,res)=>{
 const id=clean(req.params.id,70);if(!/^[A-Za-z0-9_-]+$/.test(id))return fail(res,400,'Invalid product identifier.');try{await db.collection('products').doc(id).set({id,deleted:true,active:false,updatedAt:new Date().toISOString()},{merge:true});res.json({ok:true})}catch{fail(res,503,'Product could not be removed.')}
});
router.patch('/admin/orders/:reference',sameOriginOnly,async(req,res)=>{
 const ref=req.params.reference,fulfillmentStatus=clean(req.body?.fulfillmentStatus,30);
 if(!/^PENI-[0-9a-f-]{36}$/.test(ref)||!['new','processing','shipped','delivered','cancelled'].includes(fulfillmentStatus))return fail(res,400,'Invalid order update.');
 try{const doc=db.collection('orders').doc(ref);const snap=await doc.get();if(!snap.exists)return fail(res,404,'Order not found.');if(fulfillmentStatus==='shipped'||fulfillmentStatus==='delivered'){if(snap.data().paymentStatus!=='paid')return fail(res,409,'Unpaid orders cannot be marked shipped or delivered.')}await doc.update({fulfillmentStatus,updatedAt:new Date().toISOString()});res.json({ok:true})}catch{fail(res,503,'Order could not be updated.')}
});
router.patch('/admin/messages/:id',sameOriginOnly,async(req,res)=>{
 if(!/^[A-Za-z0-9]{10,40}$/.test(req.params.id)||!['new','resolved'].includes(req.body?.status))return fail(res,400,'Invalid message update.');
 try{await db.collection('messages').doc(req.params.id).update({status:req.body.status,updatedAt:new Date().toISOString()});res.json({ok:true})}catch{fail(res,503,'Message could not be updated.')}
});
router.patch('/admin/reviews/:id',sameOriginOnly,async(req,res)=>{
 if(!/^[A-Za-z0-9]{10,40}$/.test(req.params.id)||!['pending','approved','rejected'].includes(req.body?.status))return fail(res,400,'Invalid review update.');
 try{await db.collection('reviews').doc(req.params.id).update({status:req.body.status,updatedAt:new Date().toISOString()});res.json({ok:true})}catch{fail(res,503,'Review could not be updated.')}
});
app.use('/api',router);
app.use('/',router); // Supports direct function URL and the Hosting /api/** rewrite.
app.use((req,res)=>fail(res,404,'Endpoint not found.'));
exports.api=onRequest({region:'us-central1',secrets:[paystackSecret],memory:'256MiB',timeoutSeconds:35,maxInstances:10},app);
