// Run only from a trusted local shell with Firebase Admin application credentials.
// Set GOOGLE_APPLICATION_CREDENTIALS to a private JSON key OUTSIDE this project.
const {initializeApp}=require('firebase-admin/app');
const {getAuth}=require('firebase-admin/auth');
const email=process.argv[2];
if(!email||!email.includes('@')){console.error('Usage: node scripts/grant-admin.js admin@yourdomain.com');process.exit(1)}
initializeApp();
getAuth().getUserByEmail(email).then(async user=>{
 await getAuth().setCustomUserClaims(user.uid,{...user.customClaims,admin:true});
 console.log(`Administrator claim assigned to ${email}. Sign out and back in to refresh the token.`)
}).catch(err=>{console.error('Failed:',err.message);process.exit(1)});
