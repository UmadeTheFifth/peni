'use strict';
// Dependency-free pre-deployment check. Run: node scripts/smoke-check.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const root = path.resolve(__dirname, '..');
const pub = path.join(root,'public');
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const pages = fs.readdirSync(pub).filter(f => f.endsWith('.html'));
assert.equal(pages.length, 12, 'Expected 12 PENI pages');
let assets = 0;
for (const page of pages) {
  const html = read('public/' + page);
  assert(/<title>[^<]*PENI<\/title>/i.test(html), `${page}: missing PENI title`);
  assert(/PENI/.test(html), `${page}: missing brand`);
  assert(!/9\s*Stitches|Elegance Atelier|bespoke/i.test(html), `${page}: old brand language`);
  for (const match of html.matchAll(/(?:src|href)="\/(css|js)\/([^"?#]+)"/g)) {
    const rel = `public/${match[1]}/${match[2]}`;
    assert(fs.existsSync(path.join(root,rel)), `${page}: missing asset ${rel}`);
    assets++;
  }
}
const jsFiles = fs.readdirSync(path.join(pub,'js')).filter(f => f.endsWith('.js'));
for (const filename of jsFiles) execFileSync('node', ['--check',path.join(pub,'js',filename)]);
execFileSync('node', ['--check',path.join(root,'functions/index.js')]);
execFileSync('node', ['--check',path.join(root,'functions/scripts/grant-admin.js')]);
const fbConfig = read('public/js/firebase-config.js');
assert(!/sk_(?:test|live)_/.test(fbConfig), 'Secret payment key exposed in frontend');
const backend = read('functions/index.js');
for(const snippet of ['defineSecret(\'PAYSTACK_SECRET_KEY\')','transaction/initialize','transaction/verify/',"crypto.createHmac('sha512'",'verifyIdToken(match[1],true)',"token.admin!==true","Number(data.amount)===Number(order.total)*100"]) {
  assert(backend.includes(snippet),`Required backend protection missing: ${snippet}`);
}
assert(/paymentStatus:'paid'/.test(backend), 'Missing verified payment status');
assert(/status:'failed'/.test(backend), 'Missing payment failure handling');
const seed=JSON.parse(read('functions/seed-products.json'));
const sandbox={window:{}};
vm.runInNewContext(read('public/js/products.js'), sandbox);
const fallback=sandbox.window.PENI_PRODUCTS;
assert(Array.isArray(fallback), 'Missing fallback product list');
assert.equal(fallback.length,seed.length, 'Frontend/backend product counts differ');
const validCats=new Set(['senator','agbada','traditional']);
const filterPage=read('public/catalog.html');
for (const product of seed) {
  const entry=fallback.find(x=>x.id===product.id);
  assert(entry, `Missing frontend product ${product.id}`);
  assert.equal(entry.price,product.price,`Price mismatch for ${product.id}`);
  assert(validCats.has(product.category),`Unexpected product category ${product.category}`);
  assert(filterPage.includes(`data-filter="${product.category}"`),`No filter for ${product.category}`);
}
console.log(`PASS: ${pages.length} branded pages, ${assets} local page-asset references, ${jsFiles.length} frontend scripts, ${seed.length} synchronized products.`);
console.log('PASS: backend contains server-side payment verification, webhook HMAC, and Firebase ID-token administrator authorization.');
console.log('NOTE: this check is not a substitute for live Firebase, Paystack, and browser end-to-end testing.');
