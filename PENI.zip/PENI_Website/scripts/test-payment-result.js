'use strict';
// Dependency-free UI behavior test for the payment callback page.
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const code=fs.readFileSync(path.join(__dirname,'../public/js/payment-result.js'),'utf8');
const REF='PENI-12345678-1234-4123-8123-123456789abc';
async function check(status){
  const elements={};
  for(const id of ['resultHeading','resultMessage','resultRef','resultTag','retryPayment'])
    elements[id]={textContent:'',hidden:false,disabled:false,addEventListener(event,callback){this.callback=callback}};
  let cleared=0;
  vm.runInNewContext(code,{
    URLSearchParams,location:{search:'?reference='+REF},
    document:{getElementById(id){return elements[id]}},
    fetch:async()=>({ok:true,json:async()=>({status})}),
    PeniStore:{clearCart(){cleared++}}
  });
  await new Promise(resolve=>setTimeout(resolve,15));
  return {elements,cleared};
}
(async()=>{
  for(const s of ['paid','failed','pending','unknown']){
    const {elements,cleared}=await check(s);
    assert.equal(cleared,s==='paid'?1:0,`${s}: shopping bag should clear only for paid status`);
    assert.equal(elements.retryPayment.hidden,s==='paid'||s==='unknown',`${s}: retry visibility`);
    assert.match(elements.resultHeading.textContent,s==='paid'?/SUCCESSFUL/:s==='failed'?/UNSUCCESSFUL/:s==='pending'?/PENDING/:/NOT FOUND/);
  }
  console.log('PASS: callback UI preserves bag for failed/pending/unknown and clears it only when paid.');
})().catch(err=>{console.error(err);process.exitCode=1});
